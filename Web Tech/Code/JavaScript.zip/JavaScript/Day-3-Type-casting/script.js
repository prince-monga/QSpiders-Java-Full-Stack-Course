console.log("Explicit Type catsing")

//Explicit type casting
let res=parseInt(prompt("Enter 1st number: "))
let res2=parseInt(prompt("Enter 2nd number: "))
console.log("The sum is: "+ (res+res2))


