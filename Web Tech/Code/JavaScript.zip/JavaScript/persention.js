//var
//  Declation
var a;
//  Initialization
a=10;

// decalaration and initialization in single line
var b=20;
console.log("The value of a is: "+b);


//re declation
var a=20;
// console.log(a);

//re initialization
a=30;
console.log(a);


//let


let x=10;
// let x;=20; //re declartion not allowed in let
console.log("Let variable")
x=20;
console.log(x)


//const
const pi=3.14;

console.log("Const variable")

console.log(pi);

// pi=67.3;
// console.log(pi);



let num1=45;
let num2="45";

console.log(num1==num2); //true

console.log(num1===num2); //false 


//type of operator
console.log(typeof num1);
console.log(typeof num2);