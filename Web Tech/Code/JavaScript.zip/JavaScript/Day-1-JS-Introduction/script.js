console.log("JavaScript is linked successfully!");

// Var keyword

//Decalaration
var abc;
// Initialization
abc=10;
//declaration + Initialization(Same line)
var xyz=20;

//re-declaration
var abc;

//re-initialization
xyz=50;
console.log(abc);
console.log(xyz);


// Let keyword

//Decalaration
let abcd;
// Initialization
abcd=10;
//declaration + Initialization(Same line)
let xyzz=20;

//re-declaration (Not allowed --Not possible with let keyword)
// let abc;

//re-initialization
xyzz=50;
console.log(abcd);
console.log(xyzz);


//const keyword

//Decalaration--->not possible
//const a;

// Initialization ---> not possible
//a=10;

//declaration + Initialization(Same line)
const a=20;
console.log(a);

//re-declaration (Not allowed --Not possible with const keyword)
// const a=30;
//re-initialization (Not allowed --Not possible with const keyword)
// a=50;

